Beginning with version 2.0.5 the language packs are no
longer included with the core distribution.
Language packs can be downloaded from the TinyMCE website:
http://tinymce.moxiecode.com/download.php

The language pack codes are based on ISO-639-1:
http://www.loc.gov/standards/iso639-2/englangn.html

Plrease try using entities if possible. Like &aring; etc for non a-z characters.
