// SE lang variables

tinyMCE.addToLang('advimage',{
tab_general : 'Generella instÃ¤llningar',
tab_appearance : 'Visuella instÃ¤llningar',
tab_advanced : 'Avancerade instÃ¤llningar',
general : 'Generella',
title : 'Titel',
preview : 'FÃ¶rhandsgranskning',
constrain_proportions : 'BehÃ¥ll proportionerna',
langdir : 'Skriftriktning',
langcode : 'SprÃ¥kkod',
long_desc : 'LÃ¥ng beskrivning',
style : 'Stil',
classes : 'Stilmallsklasser',
ltr : 'VÃ¤nster till hÃ¶ger',
rtl : 'HÃ¶ger till vÃ¤nster',
id : 'Id',
image_map : 'Bildkarta',
swap_image : 'Byt bild',
alt_image : 'Alternativ bild',
mouseover : 'nÃ¤r pekaren gÃ¥r Ã¶ver',
mouseout : 'nÃ¤r pekaren gÃ¥r utanfÃ¶r',
misc : 'Ã–vrigt',
example_img : 'FÃ¶rhandsgranskningsbild',
missing_alt : 'Ã„r du sÃ¤ker pÃ¥ att du vill fortsÃ¤tta utan att skriva en bildbeskrivning. Utan en alternativ beskrivning Ã¤r bilden inte handikappanpassad.'
});
