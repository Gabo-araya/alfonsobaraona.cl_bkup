// RU lang variables

tinyMCE.addToLang('flash',{
title : 'Вставить / Редактировать флеш-ролик',
desc : 'Вставить / Редактировать флеш-ролик',
file : 'Флеш-Файл (.swf)',
size : 'Размер',
list : 'Флеш-файлы',
props : 'Свойства флеш',
general : 'Основное'
});
