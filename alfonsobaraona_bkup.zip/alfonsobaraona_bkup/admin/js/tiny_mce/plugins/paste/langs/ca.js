// CA lang variables by Marc Folch

tinyMCE.addToLang('',{
paste_text_desc : 'Enganxa com a text sense format',
paste_text_title : 'Utilitza la combinaci&oacute; de tecles CTRL+V per enganxar un text.',
paste_text_linebreaks : 'Mant&eacute; els salts de l&iacute;nia',
paste_word_desc : 'Enganxa amb format (des del Word)',
paste_word_title : 'Utilitza la combinaci&oacute; de tecles CTRL+V per enganxar un text.',
selectall_desc : 'Selecciona-ho tot'
});
