// HU lang variables

tinyMCE.addToLang('',{
paste_text_desc : 'Beillesztés sima szövegként',
paste_text_title : 'Használd a CTRL+V -t a billentyûzeten a szöveg beillesztéséhez az ablakba.',
paste_text_linebreaks : 'Keep linebreaks',
paste_word_desc : 'Beillesztés Word-bõl',
paste_word_title : 'Használd a CTRL+V -t a billentyûzeten a szöveg beillesztéséhez az ablakba.',
selectall_desc : 'Mindet kijelöl'
});
