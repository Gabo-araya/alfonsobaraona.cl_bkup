// FR lang variables
// Modified by Motte, last updated 2006-03-23

/* N'oubliez pas d'identifer les parametres de langue ainsi: <votre plugin>_<un nom> */

tinyMCE.addToLang('',{
template_title : 'Texte qui appara&icirc;tra sous forme de titre dans la fen&ecirc;tre pop-up de votre plugin',
template_desc : 'Texte qui appara&icirc;tra sous forme d\'info-bulle au survol du bouton de votre plugin'
});
