// DK lang variables - Transl.:Jan Moelgaard - Corr.: Ronny Buelund

tinyMCE.addToLang('',{
preview_desc : 'Forh&aring;ndsvisning'
});
