// FR lang variables
// Modified by Motte, last updated 2006-03-23

tinyMCE.addToLang('',{
preview_desc : 'Pr&eacute;visualisation'
});
