/**
 * pt_br lang variables
 * Brazilian Portuguese
 *
 * Author
 * Revision and modifications:
 *           Marcio Barbosa (mpg) <mpg@mpg.com.br>
 * First Release : November 26, 2005 - TinyMCE Version : 2.0RC4
 * Last Updated : November 20, 2006 - TinyMCE Version : 2.0.8
 */
tinyMCE.addToLang('',{
autosave_unload_msg : 'As modificações feitas serão perdidas caso você navegue fora desta página.'
});
