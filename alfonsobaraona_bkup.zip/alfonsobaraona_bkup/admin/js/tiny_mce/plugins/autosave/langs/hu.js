// HU lang variables

tinyMCE.addToLang('',{
autosave_unload_msg : 'A módosítások el fognak veszni, ha elnavigálsz az oldalról.'
});
