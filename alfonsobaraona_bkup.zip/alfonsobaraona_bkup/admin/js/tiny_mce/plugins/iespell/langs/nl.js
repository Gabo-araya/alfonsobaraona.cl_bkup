// NL lang variables

tinyMCE.addToLang('',{
iespell_desc : 'Spellingscontrole',
iespell_download : "ieSpell niet gedetecteerd. Klik op OK om deze te downloaden."
});
