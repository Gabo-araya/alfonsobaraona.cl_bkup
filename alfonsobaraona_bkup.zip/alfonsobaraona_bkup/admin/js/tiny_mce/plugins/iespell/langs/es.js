/**
 * ES lang variables
 * 
 * Authors : Alvaro Velasco,
 *           Adolfo Sanz De Diego (asanzdiego) <asanzdiego@yahoo.es>,
 *           Carlos C Soto (eclipxe) <csoto@sia-solutions.com>
 *           Eneko Castresana Vara
 * Last Updated : July 14, 2006
 * TinyMCE Version : 2.0.6.1
 */

tinyMCE.addToLang('',{
iespell_desc : 'Ejecutar corrector ortogr&aacute;fico',
iespell_download : "Corrector ortogr&aacute;fico no detectado. Pulse OK para ir a la p&aacute;gina de descarga."
});

