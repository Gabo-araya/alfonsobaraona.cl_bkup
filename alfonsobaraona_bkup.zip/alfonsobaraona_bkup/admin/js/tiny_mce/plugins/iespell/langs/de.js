// DE lang variables

tinyMCE.addToLang('',{
iespell_desc : 'Rechtschreibpr&uuml;fung',
iespell_download : "ieSpell nicht gefunden. Klicken Sie OK, um die Download-Seite aufzurufen."
});

