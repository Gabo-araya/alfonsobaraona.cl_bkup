/**
 * pt_br lang variables
 * Brazilian Portuguese
 *
 * Author
 * Revision and modifications:
 *           Marcio Barbosa (mpg) <mpg@mpg.com.br>
 * First Release : November 20, 2006 - TinyMCE Version : 2.0.8
 */
tinyMCE.addToLang('layer',{
insertlayer_desc : 'Inserir novo layer',
forward_desc : 'Mover para frente',
backward_desc : 'Mover para trás',
absolute_desc : 'Alterar posição absoluta',
content : 'Novo layer...'
});
