// DK lang variables - Transl.:John Dalsgaard, Bo Frederiksen - Corr.:

tinyMCE.addToLang('layer',{
insertlayer_desc : 'Inds&aelig;t nyt lag',
forward_desc : 'Flyt fremad',
backward_desc : 'Flyt bagud',
absolute_desc : 'Absolut positionering til/fra',
content : 'Nyt lag...'
});
