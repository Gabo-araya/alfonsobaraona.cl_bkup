// NL lang variables

tinyMCE.addToLang('spellchecker',{
	desc : 'Spelling checker aan/uit',
	menu : 'Spelling checker instellingen',
	ignore_word : 'Negeer woord',
	ignore_words : 'Negeer alles',
	langs : 'Talen',
	wait : 'Moment...',
	swait : 'bezig met controleren, moment...',
	sug : 'Suggesties',
	no_sug : 'Geen suggesties',
	no_mpell : 'Geen spelfouten gevonden.'
});
