// SV lang variables

tinyMCE.addToLang('spellchecker',{
	desc : 'Sl&aring; av/p&aring; r&auml;ttstavning',
	menu : 'R&auml;ttstavnings inst&auml;llningar',
	ignore_word : 'Ignorera ord',
	ignore_words : 'Ignorera alla',
	langs : 'Spr&aring;k',
	wait : 'Vad god v&auml;nta...',
	swait : 'Stavningskontroll utf&ouml;rs, vad god v&auml;nta...',
	sug : 'F&ouml;rslag',
	no_sug : 'Inga f&ouml;rslag',
	no_mpell : 'Inga felstavningar kunde hittas.'
});
