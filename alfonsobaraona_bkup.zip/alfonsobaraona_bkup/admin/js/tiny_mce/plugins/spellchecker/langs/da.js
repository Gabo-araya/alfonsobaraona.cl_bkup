// DK lang variables - Transl.:John Dalsgaard, Bo Frederiksen - Corr.:

tinyMCE.addToLang('spellchecker',{
	desc : 'Stavekontrol til/fra',
	menu : 'Stavekontrol indstillinger',
	ignore_word : 'Ignorer ord',
	ignore_words : 'Ignorer alle',
	langs : 'Sprog',
	wait : 'Vent et &oslash;jeblik...',
	swait : 'Udf&oslash;rer stavekontrol, vent et &oslash;jeblik...',
	sug : 'Forslag',
	no_sug : 'Ingen forslag',
	no_mpell : 'Ingen stavefejl fundet.'
});
