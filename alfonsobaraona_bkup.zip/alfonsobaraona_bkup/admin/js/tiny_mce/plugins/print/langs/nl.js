// UK lang variables

tinyMCE.addToLang('',{
print_desc : 'Afdrukken'
});
