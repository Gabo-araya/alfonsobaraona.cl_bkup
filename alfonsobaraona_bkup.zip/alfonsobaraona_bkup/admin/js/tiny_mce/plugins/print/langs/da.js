// DK lang variables - Transl.:Jan Moelgaard - Corr.:

tinyMCE.addToLang('',{
print_desc : 'Udskriv'
});
