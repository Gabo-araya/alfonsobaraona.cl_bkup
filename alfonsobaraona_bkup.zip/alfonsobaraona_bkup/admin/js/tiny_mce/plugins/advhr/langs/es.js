// ES lang variables by Alvaro Velasco and Adolfo Sanz De Diego (asanzdiego) <asanzdiego@yahoo.es>
// Last Updated : October 2005
// TinyMCE Version : 2.0RC3

tinyMCE.addToLang('',{
insert_advhr_desc : 'Insertar/Editar Barra Horizontal',
insert_advhr_width : 'Ancho',
insert_advhr_size : 'Alto',
insert_advhr_noshade : 'Sin Sombras'
});
