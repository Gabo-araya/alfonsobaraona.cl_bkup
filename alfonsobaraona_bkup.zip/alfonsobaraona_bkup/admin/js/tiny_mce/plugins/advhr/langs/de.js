// DE lang variables

tinyMCE.addToLang('',{
insert_advhr_desc : 'Horizontale Linie einf&uuml;gen/bearbeiten',
insert_advhr_width : 'Breite',
insert_advhr_size : 'H&ouml;he',
insert_advhr_noshade : 'Kein Schatten'
});
