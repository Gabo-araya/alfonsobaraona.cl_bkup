// RU lang variables

tinyMCE.addToLang('',{
directionality_ltr_desc : 'Направление слева направо',
directionality_rtl_desc : 'Направление справа налево'
});
