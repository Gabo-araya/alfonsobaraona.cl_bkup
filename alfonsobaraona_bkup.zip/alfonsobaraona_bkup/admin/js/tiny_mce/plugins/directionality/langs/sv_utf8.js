// SV lang variables

tinyMCE.addToLang('',{
directionality_ltr_desc : 'Riktning frÃ¥n vÃ¤nster till hÃ¶ger',
directionality_rtl_desc : 'Riktning frÃ¥n hÃ¶ger till vÃ¤nster'
});
