/**
 * ES lang variables
 * 
 * Authors : Alvaro Velasco,
 *           Adolfo Sanz De Diego (asanzdiego) <asanzdiego@yahoo.es>,
 *           Carlos C Soto (eclipxe) <csoto@sia-solutions.com>
 *           Eneko Castresana Vara
 * Last Updated : July 14, 2006
 * TinyMCE Version : 2.0.6.1
 */

tinyMCE.addToLang('',{
directionality_ltr_desc : 'Direcci&oacute;n de izquierda a derecha',
directionality_rtl_desc : 'Direcci&oacute;n de derecha a izquierda'
});
