// // DK lang variables - Transl.:Jan Moelgaard, Bo Frederiksen - Corr.:

tinyMCE.addToLang('',{
fullscreen_desc : 'Skift fuldsk&aelig;rms mode'
});
