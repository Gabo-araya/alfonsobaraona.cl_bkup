// CA lang variables by Marc Folch

tinyMCE.addToLang('',{
searchreplace_search_desc : 'Cerca',
searchreplace_searchnext_desc : 'Cerca altra vegada',
searchreplace_replace_desc : 'Cerca/Reempla&ccedil;a',
searchreplace_notfound : 'La cerca ha finalitzat i l\'expressio no s\'ha trobat.',
searchreplace_search_title : 'Cerca',
searchreplace_replace_title : 'Cerca/Reempla&ccedil;a',
searchreplace_allreplaced : 'S\'han reempla&ccedil;at totes les ocurr&egrave;ncies de l\'expressi&oacute;.',
searchreplace_findwhat : 'Cerca',
searchreplace_replacewith : 'Reempla&ccedil;a amb',
searchreplace_direction : 'Direcci&oacute;',
searchreplace_up : 'Enrera',
searchreplace_down : 'Endavant',
searchreplace_case : 'Distingeix Maj&uacute;scules/min&uacute;scules',
searchreplace_findnext : 'Seg&uuml;ent',
searchreplace_replace : 'Reempla&ccedil;a',
searchreplace_replaceall : 'Tot',
searchreplace_cancel : 'Cancel&middot;la'
});
