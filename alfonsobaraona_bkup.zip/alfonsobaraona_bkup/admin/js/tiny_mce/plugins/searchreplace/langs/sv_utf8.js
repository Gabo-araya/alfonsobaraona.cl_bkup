// SE lang variables

tinyMCE.addToLang('',{
searchreplace_search_desc : 'SÃ¶k',
searchreplace_searchnext_desc : 'SÃ¶k igen',
searchreplace_replace_desc : 'SÃ¶k/ErsÃ¤tt',
searchreplace_notfound : 'SÃ¶kningen Ã¤r slutfÃ¶rd. SÃ¶kstrÃ¤ngen kunde inte hittas.',
searchreplace_search_title : 'SÃ¶k',
searchreplace_replace_title : 'SÃ¶k/ErsÃ¤tt',
searchreplace_allreplaced : 'Alla trÃ¤ffar pÃ¥ sÃ¶kstrÃ¤ngen ersattes',
searchreplace_findwhat : 'SÃ¶k pÃ¥',
searchreplace_replacewith : 'ErsÃ¤tt med',
searchreplace_direction : 'SÃ¶kriktning',
searchreplace_up : 'UppÃ¥t',
searchreplace_down : 'NerÃ¥t',
searchreplace_case : 'Matcha gemener/VERSALER',
searchreplace_findnext : 'SÃ¶k&nbsp;nÃ¤sta',
searchreplace_replace : 'ErsÃ¤tt',
searchreplace_replaceall : 'ErsÃ¤tt&nbsp;alla',
searchreplace_cancel : 'Avbryt'
});
